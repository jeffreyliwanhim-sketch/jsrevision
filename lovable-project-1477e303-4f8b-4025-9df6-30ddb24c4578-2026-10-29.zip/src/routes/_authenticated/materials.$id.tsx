import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, ExternalLink, Loader2, Pencil, Sparkles, Trash2 } from "lucide-react";
import { EditMaterialDialog, deleteMaterial } from "@/components/EditMaterialDialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { StatusPicker } from "@/components/StatusPicker";
import { Flashcards, type Card } from "@/components/study/Flashcards";
import { TranslationTable, type Row } from "@/components/study/TranslationTable";
import { PolysemyTable, type Entry } from "@/components/study/PolysemyTable";
import { useI18n, type TKey } from "@/lib/i18n";
import { daysSince, reviewState, SUBJECT_KEYS } from "@/lib/materials";
import { generateStudySet } from "@/lib/quiz.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/materials/$id")({
  head: () => ({
    meta: [
      { title: "Material — JSRevision" },
      { name: "description", content: "Read your material and revise with flashcards and Classical Chinese tables." },
      { property: "og:title", content: "Material — JSRevision" },
      { property: "og:description", content: "Read your material and revise with flashcards and Classical Chinese tables." },
    ],
  }),
  component: MaterialPage,
});

type Kind = "flashcards" | "translation" | "polysemy";

function MaterialPage() {
  const { id } = Route.useParams();
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const gen = useServerFn(generateStudySet);

  const { data: m } = useQuery({
    queryKey: ["material", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("materials").select("*").eq("id", id).single();
      if (error) throw error;
      let url: string | null = null;
      if (data.file_path) {
        const s = await supabase.storage.from("materials").createSignedUrl(data.file_path, 3600);
        url = s.data?.signedUrl ?? null;
      }
      return { ...data, url };
    },
  });
  const { data: sets = [] } = useQuery({
    queryKey: ["sets", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("study_sets").select("*").eq("material_id", id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const [tab, setTab] = useState<Kind | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const navigate = useNavigate();
  async function removeMaterial() {
    if (!m || !confirm(t("confirmDelete"))) return;
    try {
      await deleteMaterial(m.id, m.file_path);
      qc.invalidateQueries({ queryKey: ["materials"] });
      navigate({ to: "/materials" });
    } catch (e) { toast.error((e as Error).message); }
  }
  const activeTab: Kind = m?.subject === "chinese" ? (tab ?? "translation") : "flashcards";
  // 對譯對照 and 一字多義 only make sense for Classical Chinese (中文科).
  const tabs: Kind[] = m?.subject === "chinese" ? ["flashcards", "translation", "polysemy"] : ["flashcards"];
  const current = sets.find((s) => s.kind === activeTab);

  const create = useMutation({
    mutationFn: () => gen({ data: { materialId: id, kind: activeTab, lang } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sets", id] }),
    onError: (e: Error) => toast.error(e.message),
  });

  async function setSubject(subject: string) {
    await supabase.from("materials").update({ subject }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["material", id] });
    qc.invalidateQueries({ queryKey: ["materials"] });
  }
  async function markReviewed() {
    await supabase.from("materials").update({ last_reviewed_at: new Date().toISOString() }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["material", id] });
    qc.invalidateQueries({ queryKey: ["materials"] });
    toast.success(t("markedReviewed"));
  }
  async function removeSet(sid: string) {
    await supabase.from("study_sets").delete().eq("id", sid);
    qc.invalidateQueries({ queryKey: ["sets", id] });
  }

  if (!m) return <main className="p-10 text-center text-sm text-muted-foreground">…</main>;
  const isPdf = m.mime_type === "application/pdf";
  const isImg = m.mime_type?.startsWith("image/");

  return (
    <main className="mx-auto max-w-4xl px-5 py-10">
      <Link to="/materials" className="zen-hide inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" />{t("back")}
      </Link>
      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-muted-foreground">{m.kind === "past_paper" ? t("pastPaper") : t("syllabus")}</p>
          <h1 className="text-3xl font-semibold">{m.title}</h1>
          <p className={cn("mt-1 text-xs", reviewState(m) === "ok" ? "text-muted-foreground" : reviewState(m) === "now" ? "text-destructive" : "text-warning")}>
            {reviewState(m) === "now" ? `${t("reviewNow")} · ` : reviewState(m) === "overdue" ? `${t("reviewOverdue")} · ` : ""}
            {t("lastReviewed")}: {daysSince(m.last_reviewed_at)}{t("daysAgo")}
          </p>
        </div>
        <div className="zen-hide flex flex-wrap items-center gap-3">
          <select aria-label={t("subject")} value={m.subject} onChange={(e) => setSubject(e.target.value)}
            className="h-9 cursor-pointer rounded-full border bg-card px-3 text-sm">
            {SUBJECT_KEYS.map((s) => <option key={s} value={s}>{t(`subj_${s}` as TKey)}</option>)}
          </select>
          <StatusPicker id={m.id} status={m.status} />
          <Button variant="outline" size="sm" className="rounded-full" onClick={markReviewed}>{t("markReviewed")}</Button>
          <Button variant="outline" size="sm" className="rounded-full" onClick={() => setEditOpen(true)}><Pencil />{t("edit")}</Button>
          <Button variant="outline" size="sm" className="rounded-full text-destructive" onClick={removeMaterial}><Trash2 />{t("delete")}</Button>
        </div>
        <EditMaterialDialog material={m} open={editOpen} onOpenChange={setEditOpen} />
      </div>

      {m.url && isPdf && (
        <section className="mt-6">
          <div className="mb-2 flex justify-between text-sm text-muted-foreground">
            <span>{t("originalFile")}</span>
            <a href={m.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-foreground">
              {t("open")}<ExternalLink className="size-3.5" />
            </a>
          </div>
          <div className="surface mx-auto aspect-[210/297] w-full overflow-hidden">
            <iframe title={m.title} src={`${m.url}#view=FitH&toolbar=1`} className="size-full" />
          </div>
        </section>
      )}
      {m.url && isImg && (
        <section className="surface mt-6 overflow-hidden">
          <img src={m.url} alt={m.title} className="w-full" />
        </section>
      )}
      {m.content && (
        <section className="surface mt-6 p-8">
          <p className="mb-3 text-sm text-muted-foreground">{t("textContent")}</p>
          <div className="whitespace-pre-wrap text-lg leading-loose">{m.content}</div>
        </section>
      )}

      <section className="surface mt-6 p-6">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-lg font-semibold">{t("studyTools")}</h2>
          <div className="flex gap-1 rounded-full bg-secondary p-1">
            {tabs.map((k) => (
              <button key={k} onClick={() => setTab(k)}
                className={cn("rounded-full px-4 py-1.5 text-sm transition-all", activeTab === k ? "bg-card shadow-soft" : "text-muted-foreground")}>
                {t(k)}
              </button>
            ))}
          </div>
        </div>
        {current ? (
          <div key={current.id}>
            {activeTab === "flashcards" && <Flashcards cards={current.data as unknown as Card[]} onReview={markReviewed} />}
            {activeTab === "translation" && <TranslationTable rows={current.data as unknown as Row[]} />}
            {activeTab === "polysemy" && <PolysemyTable entries={current.data as unknown as Entry[]} />}
            <div className="zen-hide mt-5 flex justify-end gap-2">
              <Button size="sm" variant="ghost" onClick={() => removeSet(current.id)}><Trash2 />{t("delete")}</Button>
              <Button size="sm" variant="secondary" disabled={create.isPending} onClick={() => create.mutate()}>
                {create.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}{t("create")}
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center py-10">
            <Button size="lg" disabled={create.isPending} onClick={() => create.mutate()}>
              {create.isPending ? <><Loader2 className="animate-spin" />{t("generating")}</> : <><Sparkles />{t("create")}</>}
            </Button>
          </div>
        )}
      </section>
    </main>
  );
}
