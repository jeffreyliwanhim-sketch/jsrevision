import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertCircle, FileText, Image as ImageIcon, Pencil, Trash2, Type } from "lucide-react";
import { EditMaterialDialog, deleteMaterial, type EditableMaterial } from "@/components/EditMaterialDialog";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { StatusPicker } from "@/components/StatusPicker";
import { useI18n, type TKey } from "@/lib/i18n";
import { daysSince, materialsQuery, reviewState, SUBJECT_KEYS } from "@/lib/materials";
import { classifyMaterial } from "@/lib/quiz.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/materials/")({
  head: () => ({
    meta: [
      { title: "Materials — JSRevision" },
      { name: "description", content: "Store your exam content and past papers, sorted by subject." },
      { property: "og:title", content: "Materials — JSRevision" },
      { property: "og:description", content: "Store your exam content and past papers, sorted by subject." },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { subject?: string } =>
    typeof s["subject"] === "string" ? { subject: s["subject"] as string } : {},
  component: MaterialsPage,
});

function MaterialsPage() {
  const { t } = useI18n();
  const qc = useQueryClient();
  const classify = useServerFn(classifyMaterial);
  const [kind, setKind] = useState<"syllabus" | "past_paper">("syllabus");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const search = Route.useSearch();
  const nav = useNavigate({ from: "/materials/" });
  const subject = search.subject ?? "all";
  const setSubject = (s: string) => nav({ search: s === "all" ? {} : { subject: s } });
  const [editing, setEditing] = useState<EditableMaterial | null>(null);
  const { data: materials = [] } = useQuery(materialsQuery);

  const save = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Not signed in");
      let file_path: string | null = null;
      if (file) {
        const safe = file.name.replace(/[^\w.-]/g, "_");
        file_path = `${u.user.id}/${crypto.randomUUID()}-${safe}`;
        const { error } = await supabase.storage.from("materials").upload(file_path, file, { contentType: file.type });
        if (error) throw error;
      }
      const { data, error } = await supabase
        .from("materials")
        .insert({ title, kind, content, file_path, mime_type: file?.type ?? null })
        .select("id")
        .single();
      if (error) throw error;
      return data.id;
    },
    onSuccess: (id) => {
      setTitle("");
      setContent("");
      setFile(null);
      qc.invalidateQueries({ queryKey: ["materials"] });
      const p = classify({ data: { id } }).then(() => qc.invalidateQueries({ queryKey: ["materials"] }));
      toast.promise(p, { loading: t("classifying"), success: "✓", error: (e: Error) => e.message });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  async function remove(id: string, path: string | null, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm(t("confirmDelete"))) return;
    try { await deleteMaterial(id, path); } catch (err) { toast.error((err as Error).message); }
    qc.invalidateQueries({ queryKey: ["materials"] });
  }

  const usedSubjects = SUBJECT_KEYS.filter((s) => materials.some((m) => m.subject === s));
  const shown = subject === "all" ? materials : materials.filter((m) => m.subject === subject);
  const dueNow = materials.filter((m) => reviewState(m) === "now");
  const dueOverdue = materials.filter((m) => reviewState(m) === "overdue");
  const groups = [
    { k: "syllabus" as const, label: t("syllabus") },
    { k: "past_paper" as const, label: t("pastPaper") },
  ];
  const chip = (active: boolean) =>
    cn("rounded-full px-3.5 py-1.5 text-sm transition-all", active ? "bg-foreground text-background" : "bg-card text-muted-foreground shadow-soft hover:text-foreground");

  return (
    <main className="mx-auto grid max-w-5xl gap-6 px-5 py-10 lg:grid-cols-[320px_1fr]">
      <form
        className="surface fade-up zen-hide h-fit space-y-3 p-6"
        onSubmit={(e) => { e.preventDefault(); if (!title.trim() || (!content.trim() && !file)) return; save.mutate(); }}
      >
        <h1 className="text-lg font-semibold">{t("addMaterial")}</h1>
        <div className="grid grid-cols-2 gap-1 rounded-full bg-secondary p-1">
          {groups.map((g) => (
            <button type="button" key={g.k} onClick={() => setKind(g.k)}
              className={cn("rounded-full py-1.5 text-sm transition-all", kind === g.k ? "bg-card shadow-soft" : "text-muted-foreground")}>
              {g.label}
            </button>
          ))}
        </div>
        <Input placeholder={t("title")} value={title} onChange={(e) => setTitle(e.target.value)} className="rounded-xl" />
        <Textarea placeholder={t("pasteText")} value={content} onChange={(e) => setContent(e.target.value)} className="min-h-32 rounded-xl" />
        <label className="block text-xs text-muted-foreground">
          {t("file")}
          <input type="file" accept="application/pdf,image/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="mt-1.5 block w-full text-sm file:mr-3 file:rounded-full file:border-0 file:bg-secondary file:px-3 file:py-1.5 file:text-sm" />
        </label>
        <Button type="submit" className="w-full" disabled={save.isPending || !title.trim() || (!content.trim() && !file)}>
          {t("save")}
        </Button>
      </form>

      <section className="min-w-0 space-y-6">
        {(dueNow.length > 0 || dueOverdue.length > 0) && (
          <div className="fade-up space-y-2 rounded-2xl bg-warning/15 px-5 py-4 text-sm">
            <p className="flex items-center gap-2 font-medium"><AlertCircle className="size-5 shrink-0 text-warning" />{t("reviewToastTitle")}</p>
            {dueNow.length > 0 && (
              <p><span className="mr-2 rounded-full bg-destructive/15 px-2 py-0.5 text-xs font-medium text-destructive">{t("reviewNow")}</span>
                {dueNow.map((m, i) => <span key={m.id}>{i ? "、" : ""}<Link to="/materials/$id" params={{ id: m.id }} className="hover:underline">{m.title}</Link></span>)}
              </p>
            )}
            {dueOverdue.length > 0 && (
              <p><span className="mr-2 rounded-full bg-warning/25 px-2 py-0.5 text-xs font-medium text-warning">{t("reviewOverdue")}</span>
                {dueOverdue.map((m, i) => <span key={m.id}>{i ? "、" : ""}<Link to="/materials/$id" params={{ id: m.id }} className="hover:underline">{m.title}</Link><span className="text-muted-foreground">（{daysSince(m.last_reviewed_at)}{t("daysAgo")}）</span></span>)}
              </p>
            )}
          </div>
        )}
        {materials.length > 0 && (
          <div className="flex flex-wrap gap-2">
            <button className={chip(subject === "all")} onClick={() => setSubject("all")}>{t("all")}</button>
            {usedSubjects.map((s) => (
              <button key={s} className={chip(subject === s)} onClick={() => setSubject(s)}>{t(`subj_${s}` as TKey)}</button>
            ))}
          </div>
        )}
        {materials.length === 0 && (
          <p className="surface p-10 text-center text-sm text-muted-foreground">{t("noMaterials")}</p>
        )}
        {groups.map((g) => {
          const items = shown.filter((m) => m.kind === g.k);
          if (!items.length) return null;
          return (
            <div key={g.k} className="fade-up">
              <h2 className="mb-3 text-sm font-medium text-muted-foreground">{g.label}</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {items.map((m) => {
                  const Icon = m.mime_type?.startsWith("image/") ? ImageIcon : m.file_path ? FileText : Type;
                  return (
                    <Link key={m.id} to="/materials/$id" params={{ id: m.id }}
                      className="surface group flex items-start gap-3 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lift">
                      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent">
                        <Icon className="size-5 text-accent-foreground" strokeWidth={1.5} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{m.title}</p>
                        <p className="text-xs text-muted-foreground">{t(`subj_${m.subject}` as TKey) ?? m.subject}</p>
                        <div className="mt-2"><StatusPicker id={m.id} status={m.status} compact /></div>
                      </div>
                      <div className="flex shrink-0 gap-1 opacity-60 transition-opacity group-hover:opacity-100">
                        <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); setEditing(m); }} aria-label={t("edit")} className="rounded-full p-1.5 hover:bg-secondary">
                          <Pencil className="size-4 text-muted-foreground" />
                        </button>
                        <button onClick={(e) => remove(m.id, m.file_path, e)} aria-label={t("delete")} className="rounded-full p-1.5 hover:bg-secondary">
                          <Trash2 className="size-4 text-muted-foreground" />
                        </button>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          );
        })}
      </section>
      {editing && <EditMaterialDialog material={editing} open={!!editing} onOpenChange={(o) => !o && setEditing(null)} />}
    </main>
  );
}
