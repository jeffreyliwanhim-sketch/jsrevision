import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { ReviewReminder } from "@/components/ReviewReminder";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: () => (<><ReviewReminder /><Outlet /></>),
});
