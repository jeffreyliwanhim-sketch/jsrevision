import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useI18n, type TKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/calendar")({
  head: () => ({
    meta: [
      { title: "Calendar — JSRevision" },
      { name: "description", content: "Track key points, homework and exams day by day." },
      { property: "og:title", content: "Calendar — JSRevision" },
      { property: "og:description", content: "Track key points, homework and exams day by day." },
    ],
  }),
  component: CalendarPage,
});

const KINDS = ["note", "homework", "exam", "other"] as const;
const KIND_DOT: Record<string, string> = {
  note: "bg-primary",
  homework: "bg-warning",
  exam: "bg-destructive",
  other: "bg-muted-foreground",
};

const iso = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

function CalendarPage() {
  const { t, lang } = useI18n();
  const qc = useQueryClient();
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selected, setSelected] = useState(iso(today));
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [kind, setKind] = useState<(typeof KINDS)[number]>("note");
  const [editingId, setEditingId] = useState<string | null>(null);

  const monthStart = iso(cursor);
  const monthEnd = iso(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0));
  const { data: entries = [] } = useQuery({
    queryKey: ["entries", monthStart],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("calendar_entries")
        .select("*")
        .gte("entry_date", monthStart)
        .lte("entry_date", monthEnd)
        .order("created_at");
      if (error) throw error;
      return data;
    },
  });

  const days = useMemo(() => {
    const first = cursor.getDay();
    const count = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
    const cells: (Date | null)[] = Array(first).fill(null);
    for (let i = 1; i <= count; i++) cells.push(new Date(cursor.getFullYear(), cursor.getMonth(), i));
    while (cells.length % 7) cells.push(null);
    return cells;
  }, [cursor]);

  const refresh = () => qc.invalidateQueries({ queryKey: ["entries"] });
  const resetForm = () => {
    setEditingId(null);
    setTitle("");
    setNotes("");
    setKind("note");
  };
  const add = useMutation({
    mutationFn: async () => {
      const { error } = editingId
        ? await supabase.from("calendar_entries").update({ title, notes, kind }).eq("id", editingId)
        : await supabase.from("calendar_entries").insert({ entry_date: selected, title, notes, kind });
      if (error) throw error;
    },
    onSuccess: () => {
      resetForm();
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function startEdit(e: { id: string; title: string; notes: string; kind: string }) {
    setEditingId(e.id);
    setTitle(e.title);
    setNotes(e.notes);
    setKind((KINDS as readonly string[]).includes(e.kind) ? (e.kind as (typeof KINDS)[number]) : "note");
  }

  async function toggle(id: string, done: boolean) {
    await supabase.from("calendar_entries").update({ done }).eq("id", id);
    refresh();
  }
  async function remove(id: string) {
    await supabase.from("calendar_entries").delete().eq("id", id);
    refresh();
  }

  const locale = lang === "en" ? "en" : lang === "zh-Hant" ? "zh-HK" : "zh-CN";
  const weekdays = Array.from({ length: 7 }, (_, i) =>
    new Date(2024, 0, 7 + i).toLocaleDateString(locale, { weekday: "short" }),
  );
  const dayEntries = entries.filter((e) => e.entry_date === selected);
  const selDate = new Date(selected + "T00:00:00");

  return (
    <main className="mx-auto grid max-w-5xl gap-6 px-5 py-10 lg:grid-cols-[1fr_340px]">
      <section className="surface fade-up p-6">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="text-2xl font-semibold">
            {cursor.toLocaleDateString(locale, { year: "numeric", month: "long" })}
          </h1>
          <div className="flex items-center gap-1">
            <Button size="icon" variant="ghost" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>
              <ChevronLeft />
            </Button>
            <Button size="sm" variant="secondary" onClick={() => { setCursor(new Date(today.getFullYear(), today.getMonth(), 1)); setSelected(iso(today)); }}>
              {t("today")}
            </Button>
            <Button size="icon" variant="ghost" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>
              <ChevronRight />
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-7 text-center text-xs font-medium text-muted-foreground">
          {weekdays.map((w) => <div key={w} className="pb-3">{w}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {days.map((d, i) => {
            if (!d) return <div key={i} />;
            const key = iso(d);
            const items = entries.filter((e) => e.entry_date === key);
            const isSel = key === selected;
            const isToday = key === iso(today);
            return (
              <button
                key={key}
                onClick={() => setSelected(key)}
                className={cn(
                  "flex aspect-square flex-col items-center justify-start gap-1 rounded-2xl pt-2 text-sm transition-colors hover:bg-secondary",
                  isSel && "bg-foreground text-background hover:bg-foreground",
                )}
              >
                <span className={cn("flex size-7 items-center justify-center rounded-full", isToday && !isSel && "bg-primary text-primary-foreground")}>
                  {d.getDate()}
                </span>
                <span className="flex gap-0.5">
                  {items.slice(0, 4).map((e) => (
                    <span key={e.id} className={cn("size-1.5 rounded-full", KIND_DOT[e.kind] ?? KIND_DOT["other"])} />
                  ))}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <aside className="surface fade-up flex flex-col p-6" style={{ animationDelay: "100ms" }}>
        <h2 className="text-lg font-semibold">
          {selDate.toLocaleDateString(locale, { weekday: "long", month: "long", day: "numeric" })}
        </h2>
        <ul className="mt-4 flex-1 space-y-2">
          {dayEntries.length === 0 && <li className="text-sm text-muted-foreground">{t("nothing")}</li>}
          {dayEntries.map((e) => (
            <li key={e.id} className="group flex items-start gap-3 rounded-xl bg-secondary/60 p-3">
              <input type="checkbox" checked={e.done} onChange={(ev) => toggle(e.id, ev.target.checked)} className="mt-1 size-4 accent-primary" />
              <div className="min-w-0 flex-1">
                <p className={cn("text-sm font-medium", e.done && "text-muted-foreground line-through")}>{e.title}</p>
                <p className="text-xs text-muted-foreground">
                  <span className={cn("mr-1.5 inline-block size-1.5 rounded-full align-middle", KIND_DOT[e.kind])} />
                  {t(`kind_${e.kind}` as TKey)}
                </p>
                {e.notes && <p className="mt-1 whitespace-pre-wrap text-xs text-muted-foreground">{e.notes}</p>}
              </div>
              <div className="flex flex-col gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                <button onClick={() => startEdit(e)} aria-label={t("edit")}>
                  <Pencil className="size-4 text-muted-foreground" />
                </button>
                <button onClick={() => remove(e.id)} aria-label={t("delete")}>
                  <Trash2 className="size-4 text-muted-foreground" />
                </button>
              </div>
            </li>
          ))}
        </ul>
        <form
          className="mt-6 space-y-2 border-t pt-5"
          onSubmit={(e) => { e.preventDefault(); if (title.trim()) add.mutate(); }}
        >
          <div className="flex flex-wrap gap-1.5">
            {KINDS.map((k) => (
              <button
                type="button"
                key={k}
                onClick={() => setKind(k)}
                className={cn("rounded-full px-3 py-1 text-xs transition-colors", kind === k ? "bg-foreground text-background" : "bg-secondary text-muted-foreground")}
              >
                {t(`kind_${k}` as TKey)}
              </button>
            ))}
          </div>
          <Input placeholder={t("title")} value={title} onChange={(e) => setTitle(e.target.value)} className="rounded-xl" />
          <Textarea placeholder={t("notes")} value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-16 rounded-xl" />
          <div className="flex gap-2">
            <Button type="submit" className="flex-1" disabled={add.isPending || !title.trim()}>
              {editingId ? t("save") : t("add")}
            </Button>
            {editingId && (
              <Button type="button" variant="secondary" onClick={resetForm}>{t("cancel")}</Button>
            )}
          </div>
        </form>
      </aside>
    </main>
  );
}
