import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ChevronDown, Loader2, NotebookPen, Sparkles, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { generateNotes, generateQuiz } from "@/lib/quiz.functions";
import { Notes, type NoteSection } from "@/components/study/Notes";

export const Route = createFileRoute("/_authenticated/practice/")({
  head: () => ({
    meta: [
      { title: "Practice — JSRevision" },
      { name: "description", content: "Generate AI quizzes and mock papers from your materials." },
      { property: "og:title", content: "Practice — JSRevision" },
      { property: "og:description", content: "Generate AI quizzes and mock papers from your materials." },
    ],
  }),
  component: PracticePage,
});

function PracticePage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const gen = useServerFn(generateQuiz);
  const genNotes = useServerFn(generateNotes);
  const qc = useQueryClient();
  const [openNote, setOpenNote] = useState<string | null>(null);
  const [picked, setPicked] = useState<string[]>([]);
  const [mode, setMode] = useState<"quiz" | "mock">("quiz");
  const [count, setCount] = useState(10);

  const { data: materials = [] } = useQuery({
    queryKey: ["materials"],
    queryFn: async () => {
      const { data, error } = await supabase.from("materials").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
  const { data: quizzes = [] } = useQuery({
    queryKey: ["quizzes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quizzes")
        .select("id,title,mode,score,total,created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  // Default to the most recently uploaded past paper as a mock exam.
  useEffect(() => {
    if (picked.length) return;
    const latest = materials.find((m) => m.kind === "past_paper");
    if (latest) {
      setPicked([latest.id]);
      setMode("mock");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [materials]);

  const run = useMutation({
    mutationFn: () => gen({ data: { materialIds: picked, mode, count, lang } }),
    onSuccess: (r) => navigate({ to: "/practice/$id", params: { id: r.id } }),
    onError: (e: Error) => toast.error(e.message),
  });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("study_sets")
        .select("id,title,data,created_at")
        .eq("kind", "notes")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const noteRun = useMutation({
    mutationFn: () => genNotes({ data: { materialIds: picked, lang } }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["notes"] });
      setOpenNote(r.id);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const delNote = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("study_sets").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notes"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const togglePick = (id: string) =>
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  return (
    <main className="mx-auto grid max-w-5xl gap-6 px-5 py-10 lg:grid-cols-[1fr_320px]">
      <section className="surface fade-up p-6">
        <h1 className="text-2xl font-semibold">{t("practice")}</h1>
        <h2 className="mt-6 mb-3 text-sm font-medium text-muted-foreground">{t("pickMaterials")}</h2>
        {materials.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {t("noMaterials")} <Link to="/materials" className="text-primary hover:underline">{t("materials")} →</Link>
          </p>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2">
            {materials.map((m) => (
              <button
                key={m.id}
                onClick={() => togglePick(m.id)}
                className={cn(
                  "rounded-xl border p-3 text-left text-sm transition-all",
                  picked.includes(m.id) ? "border-primary bg-accent" : "hover:bg-secondary",
                )}
              >
                <p className="font-medium">{m.title}</p>
                <p className="text-xs text-muted-foreground">{m.kind === "past_paper" ? t("pastPaper") : t("syllabus")}</p>
              </button>
            ))}
          </div>
        )}

        <div className="mt-6 flex flex-wrap items-end gap-6">
          <div>
            <p className="mb-2 text-sm font-medium text-muted-foreground">{t("mode")}</p>
            <div className="flex gap-1 rounded-full bg-secondary p-1">
              {(["quiz", "mock"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={cn("rounded-full px-4 py-1.5 text-sm transition-all", mode === m ? "bg-card shadow-soft" : "text-muted-foreground")}
                >
                  {m === "quiz" ? t("modeQuiz") : t("modeMock")}
                </button>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-sm font-medium text-muted-foreground">{t("count")}: {count}</p>
            <input type="range" min={3} max={30} value={count} onChange={(e) => setCount(Number(e.target.value))} className="w-40 accent-primary" />
          </div>
        </div>

        <Button
          size="lg"
          className="mt-8 w-full"
          disabled={run.isPending}
          onClick={() => (picked.length ? run.mutate() : toast.error(t("needMaterial")))}
        >
          {run.isPending ? <><Loader2 className="animate-spin" />{t("generating")}</> : <><Sparkles />{t("generate")}</>}
        </Button>

        <div className="mt-10 border-t pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="flex items-center gap-2 text-lg font-semibold">
              <NotebookPen className="size-5 text-primary" />{t("aiNotes")}
            </h2>
            <Button
              variant="secondary"
              disabled={noteRun.isPending}
              onClick={() => (picked.length ? noteRun.mutate() : toast.error(t("needMaterial")))}
            >
              {noteRun.isPending ? <><Loader2 className="animate-spin" />{t("generating")}</> : <><Sparkles />{t("makeNotes")}</>}
            </Button>
          </div>
          <ul className="mt-4 space-y-2">
            {notes.length === 0 && <li className="text-sm text-muted-foreground">{t("noNotes")}</li>}
            {notes.map((n) => (
              <li key={n.id} className="rounded-xl border">
                <div className="flex items-center gap-2 p-3">
                  <button
                    className="flex min-w-0 flex-1 items-center gap-2 text-left"
                    onClick={() => setOpenNote(openNote === n.id ? null : n.id)}
                  >
                    <ChevronDown className={cn("size-4 shrink-0 transition-transform", openNote !== n.id && "-rotate-90")} />
                    <span className="truncate text-sm font-medium">{n.title}</span>
                    <span className="shrink-0 text-xs text-muted-foreground">
                      {new Date(n.created_at).toLocaleDateString()}
                    </span>
                  </button>
                  <button
                    aria-label={t("delete")}
                    className="text-muted-foreground transition-colors hover:text-destructive"
                    onClick={() => delNote.mutate(n.id)}
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
                {openNote === n.id && (
                  <div className="border-t p-5">
                    <Notes sections={(n.data as unknown as NoteSection[]) ?? []} />
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <aside className="surface fade-up h-fit p-6" style={{ animationDelay: "100ms" }}>
        <h2 className="text-lg font-semibold">{t("history")}</h2>
        <ul className="mt-4 space-y-1">
          {quizzes.length === 0 && <li className="text-sm text-muted-foreground">{t("noQuizzes")}</li>}
          {quizzes.map((q) => (
            <li key={q.id}>
              <Link to="/practice/$id" params={{ id: q.id }} className="flex items-center justify-between gap-3 rounded-xl p-2.5 hover:bg-secondary">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{q.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {q.mode === "mock" ? t("modeMock") : t("modeQuiz")} · {new Date(q.created_at).toLocaleDateString()}
                  </p>
                </div>
                {q.score != null && (
                  <span className="shrink-0 text-sm font-medium text-primary">{q.score}/{q.total}</span>
                )}
              </Link>
            </li>
          ))}
        </ul>
      </aside>
    </main>
  );
}
