import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Check, Download, X } from "lucide-react";
import { PaperSheet } from "@/components/PaperSheet";
import { exportSheetToPdf } from "@/lib/pdf";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

type Q = { type: "mcq" | "short"; question: string; options: string[]; answer: string; explanation: string; marks: number; keywords?: string[]; optionNotes?: string[] };

export const Route = createFileRoute("/_authenticated/practice/$id")({
  head: () => ({
    meta: [
      { title: "Quiz — JSRevision" },
      { name: "description", content: "Answer your AI-generated questions." },
      { property: "og:title", content: "Quiz — JSRevision" },
      { property: "og:description", content: "Answer your AI-generated questions." },
    ],
  }),
  component: QuizPage,
});

function QuizPage() {
  const { id } = Route.useParams();
  const { t } = useI18n();
  const qc = useQueryClient();
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [selfMark, setSelfMark] = useState<Record<number, boolean>>({});
  const [submitted, setSubmitted] = useState(false);
  const [reveal, setReveal] = useState(false);
  const shown = submitted || reveal;
  const [pdfBusy, setPdfBusy] = useState<null | "paper" | "scheme">(null);
  const sheetRef = useRef<HTMLDivElement>(null);

  const { data: quiz, isLoading } = useQuery({
    queryKey: ["quiz", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("quizzes").select("*").eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

  if (isLoading || !quiz) return <main className="p-10 text-center text-sm text-muted-foreground">…</main>;
  const questions = (quiz.questions as unknown as Q[]) ?? [];

  const isRight = (q: Q, i: number) =>
    q.type === "mcq" ? answers[i]?.trim() === q.answer.trim() : !!selfMark[i];
  const score = questions.filter((q, i) => isRight(q, i)).length;

  async function downloadPdf(variant: "paper" | "scheme") {
    setPdfBusy(variant);
    await new Promise((r) => setTimeout(r, 60));
    try {
      const name = `${quiz!.title} - ${variant === "paper" ? t("paperPdf") : t("schemePdf")}`.replace(/[\\/:*?"<>|]/g, "_");
      await exportSheetToPdf(sheetRef.current!, `${name}.pdf`);
    } finally {
      setPdfBusy(null);
    }
  }

  async function finish() {
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  async function saveScore() {
    await supabase.from("quizzes").update({ score, total: questions.length }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["quizzes"] });
  }

  return (
    <main className="mx-auto max-w-2xl px-5 py-10">
      <Link to="/practice" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" />{t("back")}
      </Link>
      <h1 className="mt-4 text-3xl font-semibold">{quiz.title}</h1>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="outline" size="sm" disabled={!!pdfBusy} onClick={() => downloadPdf("paper")}>
          <Download />{t("paperPdf")}
        </Button>
        <Button variant="outline" size="sm" disabled={!!pdfBusy} onClick={() => downloadPdf("scheme")}>
          <Download />{t("schemePdf")}
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setReveal((v) => !v)}>
          {reveal ? t("hideAnswers") : t("showAnswers")}
        </Button>
      </div>
      {pdfBusy && (
        <div className="pointer-events-none fixed left-[-10000px] top-0">
          <div ref={sheetRef}>
            <PaperSheet title={quiz.title} questions={questions} variant={pdfBusy} />
          </div>
        </div>
      )}
      {submitted && (
        <div className="surface fade-up mt-6 flex items-center justify-between p-6">
          <div>
            <p className="text-sm text-muted-foreground">{t("score")}</p>
            <p className="text-4xl font-semibold">{score}<span className="text-muted-foreground">/{questions.length}</span></p>
          </div>
          <Button variant="secondary" onClick={() => { setAnswers({}); setSelfMark({}); setSubmitted(false); }}>{t("retry")}</Button>
        </div>
      )}
      <ol className="mt-8 space-y-4">
        {questions.map((q, i) => (
          <li key={i} className="surface fade-up p-6" style={{ animationDelay: `${Math.min(i, 8) * 50}ms` }}>
            <div className="flex items-start justify-between gap-4">
              <p className="whitespace-pre-wrap font-medium"><span className="mr-2 text-muted-foreground">{i + 1}.</span>{q.question}</p>
              <span className="shrink-0 text-xs text-muted-foreground">[{q.marks}]</span>
            </div>
            {q.type === "mcq" ? (
              <div className="mt-4 space-y-2">
                {q.options.map((o) => {
                  const chosen = answers[i] === o;
                  const correct = shown && o === q.answer;
                  const wrong = submitted && chosen && o !== q.answer;
                  return (
                    <button
                      key={o}
                      disabled={submitted}
                      onClick={() => setAnswers({ ...answers, [i]: o })}
                      className={cn(
                        "flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left text-sm transition-all",
                        chosen && !submitted && "border-primary bg-accent",
                        !chosen && !submitted && "hover:bg-secondary",
                        correct && "border-success bg-success/10",
                        wrong && "border-destructive bg-destructive/10",
                      )}
                    >
                      {o}
                      {correct && <Check className="size-4 text-success" />}
                      {wrong && <X className="size-4 text-destructive" />}
                    </button>
                  );
                })}
              </div>
            ) : (
              <Textarea
                disabled={submitted}
                placeholder={t("yourAnswer")}
                value={answers[i] ?? ""}
                onChange={(e) => setAnswers({ ...answers, [i]: e.target.value })}
                className="mt-4 min-h-24 rounded-xl"
              />
            )}
            {shown && (
              <div className="mt-4 rounded-xl bg-secondary/70 p-4 text-sm">
                {(
                  <p className="mb-2"><span className="font-medium">{t("answer")}: </span><span className="whitespace-pre-wrap">{q.answer}</span></p>
                )}
                {q.explanation && <p className="whitespace-pre-wrap text-muted-foreground"><span className="font-medium text-foreground">{t("explanation")}: </span>{q.explanation}</p>}
                {q.type === "mcq" && (q.optionNotes?.length ?? 0) > 0 && (
                  <div className="mt-3">
                    <p className="font-medium">{t("optionAnalysis")}</p>
                    <ul className="mt-1 space-y-1">
                      {q.options.map((o, j) => q.optionNotes?.[j] ? (
                        <li key={j} className="flex gap-2 text-muted-foreground">
                          {o === q.answer ? <Check className="mt-0.5 size-4 shrink-0 text-success" /> : <X className="mt-0.5 size-4 shrink-0 text-destructive" />}
                          <span><span className="text-foreground">{String.fromCharCode(65 + j)}.</span> {q.optionNotes[j]}</span>
                        </li>
                      ) : null)}
                    </ul>
                  </div>
                )}
                {submitted && q.type === "short" && (
                  <label className="mt-3 flex items-center gap-2">
                    <input type="checkbox" className="size-4 accent-primary" checked={!!selfMark[i]} onChange={(e) => setSelfMark({ ...selfMark, [i]: e.target.checked })} />
                    {t("markCorrect")}
                  </label>
                )}
              </div>
            )}
          </li>
        ))}
      </ol>
      <Button size="lg" className="mt-8 w-full" onClick={submitted ? saveScore : finish}>
        {submitted ? t("save") : t("submit")}
      </Button>
    </main>
  );
}
