import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarDays, FileText, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JSRevision — Revise smarter" },
      { name: "description", content: "Study calendar, exam materials and AI quizzes modelled on your past papers." },
      { property: "og:title", content: "JSRevision — Revise smarter" },
      { property: "og:description", content: "Study calendar, exam materials and AI quizzes modelled on your past papers." },
    ],
  }),
  component: Index,
});

function Index() {
  const { t } = useI18n();
  const { session } = useAuth();
  const features = [
    { icon: CalendarDays, title: t("f1"), desc: t("f1d") },
    { icon: FileText, title: t("f2"), desc: t("f2d") },
    { icon: Sparkles, title: t("f3"), desc: t("f3d") },
  ];
  return (
    <main className="mx-auto max-w-5xl px-5">
      <section className="fade-up flex flex-col items-center pb-20 pt-28 text-center">
        <p className="mb-4 text-sm font-medium text-primary">JSRevision</p>
        <h1 className="text-5xl font-semibold sm:text-7xl">{t("tagline")}</h1>
        <p className="mt-6 max-w-xl text-lg text-muted-foreground sm:text-xl">{t("heroSub")}</p>
        <div className="mt-10 flex gap-3">
          <Button asChild size="lg" variant="hero">
            <Link to={session ? "/calendar" : "/auth"}>{t("getStarted")}</Link>
          </Button>
        </div>
      </section>
      <section className="grid gap-4 pb-28 sm:grid-cols-3">
        {features.map((f, i) => (
          <div key={f.title} className="surface fade-up p-7" style={{ animationDelay: `${150 + i * 100}ms` }}>
            <f.icon className="size-7 text-primary" strokeWidth={1.5} />
            <h3 className="mt-5 text-lg font-semibold">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
