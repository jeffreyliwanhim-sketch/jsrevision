import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — JSRevision" },
      { name: "description", content: "Sign in to JSRevision to plan, store materials and practise." },
      { property: "og:title", content: "Sign in — JSRevision" },
      { property: "og:description", content: "Sign in to JSRevision to plan, store materials and practise." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { t } = useI18n();
  const { session } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (session) navigate({ to: "/calendar", replace: true });
  }, [session, navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) toast.error(error.message);
    } else {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: window.location.origin },
      });
      if (error) toast.error(error.message);
      else if (!data.session) toast.success(t("checkEmail"));
    }
    setBusy(false);
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) toast.error(String(r.error.message ?? r.error));
  }

  return (
    <main className="flex min-h-[calc(100vh-3.5rem)] items-center justify-center px-5">
      <div className="surface fade-up w-full max-w-sm p-8">
        <h1 className="text-center text-2xl font-semibold">{mode === "in" ? t("signIn") : t("signUp")}</h1>
        <Button variant="outline" className="mt-7 w-full" onClick={google}>{t("google")}</Button>
        <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
          <div className="h-px flex-1 bg-border" />{t("or")}<div className="h-px flex-1 bg-border" />
        </div>
        <form onSubmit={submit} className="space-y-3">
          <Input type="email" required placeholder={t("email")} value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" />
          <Input type="password" required minLength={6} placeholder={t("password")} value={password} onChange={(e) => setPassword(e.target.value)} className="h-11 rounded-xl" />
          <Button type="submit" className="w-full" disabled={busy}>{mode === "in" ? t("signIn") : t("signUp")}</Button>
        </form>
        <p className="mt-6 text-center text-sm text-muted-foreground">
          {mode === "in" ? t("noAccount") : t("haveAccount")}{" "}
          <button className="text-primary hover:underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
            {mode === "in" ? t("signUp") : t("signIn")}
          </button>
        </p>
      </div>
    </main>
  );
}
